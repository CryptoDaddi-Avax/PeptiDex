import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import Link from "next/link";
import { GoogleAnalytics } from "@next/third-parties/google";
import "./globals.css";
import { Suspense } from "react";
import { Header } from "@/components/header";
import { BottomNav } from "@/components/bottom-nav";
import { DisclaimerBanner } from "@/components/disclaimer-banner";
import { FirstVisitModal } from "@/components/first-visit-modal";
import { PWAInstallPrompt } from "@/components/pwa-install-prompt";
import { Footer } from "@/components/footer";
import { AutoLinkProvider } from "@/components/auto-link";
import { LeadMagnetPopup } from "@/components/lead-magnet-popup";
import { GlobalEmbedHandler } from "@/components/global-embed-handler";
import { MobileSourcingBar } from "@/components/mobile-sourcing-bar";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-geist-sans",
  display: "swap",
  preload: true,
});

export const metadata: Metadata = {
  metadataBase: new URL("https://peptidex.app"),
  alternates: {
    languages: {
      "en": "https://peptidex.app",
    },
  },
  title: {
    default: "PeptiDex: Independent Peptide Research",
    template: "%s | PeptiDex",
  },
  description: "Explore 30+ research peptides like BPC-157 and Tirzepatide. Access clinical studies, reconstitution tools, half-life graphs, and COA databases.",
  keywords: [
    "peptide research", "BPC-157", "TB-500", "Semaglutide", "CJC-1295", "Ipamorelin",
    "peptide reconstitution calculator", "peptide half-life", "research peptides", "peptide COA",
    "peptide stack", "GHK-Cu", "Thymosin Alpha-1", "Retatrutide", "Tirzepatide",
    "peptide interactions", "research chemicals", "peptide suppliers", "peptide guide",
    "pharmacokinetics", "HPLC verified peptides",
  ],
  authors: [{ name: "PeptiDex" }],
  creator: "PeptiDex",
  publisher: "PeptiDex",
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large" },
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    siteName: "PeptideX",
    title: "PeptiDex Research-Grade Peptide Reference & Tools",
    description: "The most comprehensive peptide research platform. Explore 33 peptides with clinical studies, reconstitution tools, PK plasma graphs, COA verification, and AI recommendations.",
    url: "https://peptidex.app",
    images: [{ url: "https://peptidex.app/api/og?type=default", width: 1200, height: 630, alt: "PeptideX: Evidence-Based Peptide Science" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "PeptiDex Research-Grade Peptide Reference & Tools",
    description: "The most comprehensive peptide research platform. Clinical studies, reconstitution tools, COA verification, and AI recommendations.",
    images: ["https://peptidex.app/api/og?type=default"],
  },
  manifest: "/site.webmanifest",
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "any" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180" },
      { url: "/apple-touch-icon-152.png", sizes: "152x152" },
      { url: "/apple-touch-icon-120.png", sizes: "120x120" },
      { url: "/apple-touch-icon-76.png", sizes: "76x76" },
    ],
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "PeptiDex",
  },
};


export const viewport: Viewport = {
  themeColor: "#0a0a0b",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        {/* DNS prefetch for external resources */}
        <link rel="dns-prefetch" href="https://www.googletagmanager.com" />

        {/* Google Fonts — Fraunces (serif), Inter (sans), JetBrains Mono (mono) */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,300;1,9..144,400&family=JetBrains+Mono:wght@300;400;500&family=Inter:wght@300;400;500;600&display=swap"
          rel="stylesheet"
        />

        {/* SEO / PWA meta tags */}
        <meta name="theme-color" content="#0a0a0b" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="PeptiDex" />
        <meta name="format-detection" content="telephone=no" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
        <link rel="shortcut icon" href="/favicon.ico" />
        <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#c9a961" />
        <link rel="manifest" href="/site.webmanifest" />
        <meta name="msapplication-TileColor" content="#0a0a0b" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
             __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              "name": "PeptiDex",
              "url": "https://peptidex.app",
              "description": "Peptide science education, research news, and compound profiles. Trusted source for evidence-based peptide information.",
              "logo": "https://peptidex.app/logo.png",
              "sameAs": [
                 "https://twitter.com/peptidex",
                 "https://facebook.com/peptidex"
              ]
            })
          }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
             __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebSite",
              "url": "https://peptidex.app/",
              "potentialAction": {
                "@type": "SearchAction",
                "target": "https://peptidex.app/search?q={search_term_string}",
                "query-input": "required name=search_term_string"
              }
            })
          }}
        />
      </head>
      <body className={`${inter.variable} font-sans antialiased bg-zinc-950 text-zinc-100 min-h-screen`}>
        <GoogleAnalytics gaId="G-FBJ7CJVJK9" />
        {/* Skip to content - accessibility */}
        <a href="#main-content" className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[100] focus:px-4 focus:py-2 focus:bg-violet-600 focus:text-white focus:rounded-lg focus:text-sm focus:font-medium">
          Skip to main content
        </a>
        <div id="site-header-container"><Header /></div>
        <div id="site-first-visit-container"><FirstVisitModal /></div>
        <div id="site-pwa-container"><PWAInstallPrompt /></div>
        <AutoLinkProvider>
          <main id="main-content" role="main" className="pb-16 min-h-[calc(100vh-64px)]">
            {children}
          </main>
          <div id="site-disclaimer-container" className="hidden md:block fixed bottom-14 left-0 right-0 z-40 pointer-events-none">
            <DisclaimerBanner />
          </div>
          <div id="site-footer-container"><Footer /></div>
        </AutoLinkProvider>

        <div id="site-lead-container"><LeadMagnetPopup source="global_exit_intent" /></div>
        <div id="site-mobilesource-container"><MobileSourcingBar /></div>
        <div id="site-bottomnav-container"><BottomNav /></div>
        
        <Suspense fallback={null}>
          <GlobalEmbedHandler />
        </Suspense>
      </body>
    </html>
  );
}
