/**
 * Supabase SSR client for server components and API routes.
 * Uses cookies for session management (not the service role key).
 * Import this in server components — NOT supabase-server.ts (which bypasses RLS).
 */
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

export async function createSSRClient() {
    const cookieStore = await cookies();

    return createServerClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
        {
            cookies: {
                getAll() {
                    return cookieStore.getAll();
                },
                setAll(cookiesToSet) {
                    try {
                        cookiesToSet.forEach(({ name, value, options }) =>
                            cookieStore.set(name, value, options)
                        );
                    } catch {
                        // setAll is called from a Server Component where cookies
                        // cannot be set. This is fine — the middleware will handle it.
                    }
                },
            },
        }
    );
}
